package org.studyeasy.app.DAO;

import java.util.List;

import org.studyeasy.app.entity.Product;

public interface ProductDAO {
	
	public List<Product> getProducts();
}
